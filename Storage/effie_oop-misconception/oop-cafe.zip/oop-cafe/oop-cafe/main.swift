//
//  main.swift
//  oop-cafe
//
//  Created by Effie on 1/12/24.
//

SyncCafe().run()
