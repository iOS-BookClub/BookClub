//
//  SyncCafe.swift
//  oop-cafe
//
//  Created by Effie on 1/12/24.
//

// [가정]
// 실제 환경과 다르게 주문 및 제조가 동기적으로 진행된다
// 손님, 캐시어, 바리스타 한 명씩

// [구현하고자 하는 기능]
// 손님이 주문한 커피를 받아들고 인사하는 기능

struct SyncCafe {
    func run() {
        let effie = Customer()
        effie.orderDrink()
    }
}
