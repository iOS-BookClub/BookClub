//
//  OrderMakable.swift
//  oop-cafe
//
//  Created by Effie on 1/12/24.
//

protocol OrderMakable {
    func makeOrderAndReturn(menu: Menu) -> Drink
}

final class Cashier: OrderMakable {
    func makeOrderAndReturn(menu: Menu) -> Drink {
        let order = Order(menu: menu)
        let drinkMaker: DrinkMakable = Student()
        let orderResult = drinkMaker.makeDrinkAndReturn(order: order)
        return orderResult
    }
}

final class Sajang: OrderMakable {
    let juiceMakerPool: [DrinkMakable] = []
    
    func makeOrderAndReturn(menu: Menu) -> Drink {
        let order = Order(menu: menu)
        let drinkMaker: DrinkMakable = juiceMakerPool.randomElement() ?? self
        let orderResult = drinkMaker.makeDrinkAndReturn(order: order)
        return orderResult
    }
}
