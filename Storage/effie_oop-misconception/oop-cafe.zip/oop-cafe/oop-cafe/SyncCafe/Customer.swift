//
//  Customer.swift
//  oop-cafe
//
//  Created by Effie on 1/12/24.
//

final class Customer {
    var isBusy: Bool
    
    init() {
        self.isBusy = .random()
    }
    
    func orderDrink() {
        let cashier: OrderMakable = Sajang()
        let drink = cashier.makeOrderAndReturn(menu: .coffee)
        self.isBusy ? sayBriefly() : sayFullSentence(drink: drink)
    }
    
    private func sayBriefly() {
        print("잘 마실게요 :)")
    }
    
    private func sayFullSentence(drink: Drink) {
        print("\(drink.description) \(drink.menu.name) 잘 마실게요 :)")
    }
}
