//
//  Order.swift
//  oop-cafe
//
//  Created by Effie on 1/12/24.
//

/// 손님이 발행한 주문
struct Order {
    let menu: Menu
}

/// 주문할 수 있는 메뉴 종류
enum Menu {
    case coffee
    
    var name: String {
        switch self {
        case .coffee: return "커피"
        }
    }
}

/// 제조 결과
struct Drink {
    let description: String
    
    let menu: Menu
}

