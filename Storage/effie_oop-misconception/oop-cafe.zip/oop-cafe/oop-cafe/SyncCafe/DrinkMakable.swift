//
//  DrinkMakable.swift
//  oop-cafe
//
//  Created by Effie on 1/12/24.
//

protocol DrinkMakable {
    func makeDrinkAndReturn(order: Order) -> Drink
}

final class Baristar: DrinkMakable {
    func makeDrinkAndReturn(order: Order) -> Drink {
        return Drink(description: "맛있는", menu: order.menu)
    }
}

final class Student: DrinkMakable {
    func makeDrinkAndReturn(order: Order) -> Drink {
        return Drink(description: "어설프지만 형식은 갖춘", menu: order.menu)
    }
}

extension Sajang: DrinkMakable {
    func makeDrinkAndReturn(order: Order) -> Drink {
        return Drink(description: "빠르고 깔끔하게 만든", menu: order.menu)
    }
}
